# Reproducing the Tucker3 manuscript analyses

This package reproduces selections and summaries from the archived candidate fits underlying the ChJS manuscript. It does not claim that a fresh stochastic run has been independently reproduced.

## Run the verification

Unzip into a writable directory, open R there, and run:

    source("reproduce.R", encoding="UTF-8")

Alternatively: `Rscript reproduce.R .` from the package directory. This base-R script loads function definitions only; it does not start either simulation. It independently recalculates all four selectors on 5,400 saved candidate-fit sets and compares 21,600 selected triplets with the source programs and saved results. It exports CSV summaries and paired Monte Carlo intervals under `verification`.

For the eight controlled DIFFIT variants, core-rank/noise checks, modal dimensions, and an exact check of empirical preprocessing, install `openxlsx` once and then run:

    source("verify_controls_and_preprocessing.R", encoding="UTF-8")

Run these commands from the package root. Output files are regenerated within `verification`; source data are not overwritten. The supplemental check recalculates controlled selections from archived curves and compares them with saved diagnostic records. Archived curves are derived from the same fitted candidates.

## Provenance and contents

- `data/simulation`: complete 15 September 2026 run; 108 scenarios, 50 replications each, 37 retained candidates per array. The partial 2 October run is not used.
- `code/simulation_V2.R`: original generating/fitting program, unchanged. Seed 2026; 20 starts; 500 iterations; absolute FIT tolerance 1e-7 percentage points. R 4.5.1 was used.
- `code/simulation_V1.R`: reference selection rules. In the paper V1 is applied to the same saved fits as V2, not to an independently generated sample.
- `data/V1_comparison.rds`: archived version comparison; `data/controlled_results.rds`: controlled diagnostic results, curves, contrasts, and method notes.
- `data/observed_data.xlsx`: empirical data (24 territories, 12 activities, years 2007–2024), thousands of soles at constant 2007 prices, from https://doi.org/10.6084/m9.figshare.33440566 (public version inspected 5 October 2026). Original source INEI SIRTOD.
- `data/empirical_reference.rds`: 68 reference candidate fits and the preprocessed array. `data/empirical_V1_candidates.csv`: 67 earlier candidate fits, extracted without changing numeric values from the authors' workbook.
- `code/empirical_original.R`: original empirical analysis code, with only the input path changed to `data/observed_data.xlsx` for portability. The verification script evaluates only its import/preprocessing block.
- `verification`: recalculated summaries and checks. All CSV files are static calculated values. Recovery percentages use 0–100; MCSE and differences use percentage points. NA indicates an undefined value. Global weights are 75% clustered and 25% random.
- `manifest_sha256.csv`: file integrity checks; generated before packaging, excluding the manifest itself.

## What was verified

No selected-triplet discrepancies across all 5,400 replications. All 43,200 controlled DIFFIT selections agree with the archived diagnostics. Empirical preprocessing exactly reproduces the saved array. The empirical V1 and V2 selections are reproduced on both candidate sets. No full ALS simulation was rerun for this audit. Three retained simulation candidates failed convergence; neither V2 selector chose them. The metadata field referring to logistic regression describes an older export; logistic coefficients are not used in the manuscript, whose inference uses paired, scenario-stratified Monte Carlo summaries.

## New simulation runs

The original V2 program can be run with `source("code/simulation_V2.R", encoding="UTF-8")`, after installing `openxlsx`. It starts the full, computationally expensive experiment immediately. Environment variables can override settings; clear pilot overrides before attempting a full run. A new run creates a new results directory. The global RNG stream depends on design order and fitting operations, so changing the starts, candidate grid, or scenario order changes subsequent samples. This audit reuses fitted candidates and does not certify cross-platform bitwise reproducibility of new ALS runs. Preserve archived fits when reproducing the published comparisons.

## Controlled comparisons and Excel output

Run `source("controlled_comparisons.R", encoding="UTF-8")` from this directory after installing `openxlsx`. This regenerates the eight controlled DIFFIT variants, two scree variants, reference selections, summaries and paired contrasts directly from the 5,400 candidate-fit sets. Outputs (including `Comparaciones_controladas_Tucker3.xlsx`) are written to `controlled_outputs`. Existing files there are overwritten; the input fits are not changed. The workbook contains calculated values, not Excel formulas. Undefined selections are retained as NA: recovery counts these as failures; means of selected quantities exclude them.

## Scope and public sources

V1 means the authors' initial implementation, not an assertion of exact equivalence to an original publication. V2 denotes the alternative implemented rules. The controlled comparisons isolate implementation components; they are not independent validation and must not be used to choose a rule solely for its performance on these same simulations. Both scree rules are automated, not human visual assessments. No CHull comparison is included.

Repository: https://github.com/joluvasquez/Tucker3-Dimensionalidad

Empirical data and earlier empirical code: https://doi.org/10.6084/m9.figshare.33440566 . The Figshare dataset is labelled CC BY 4.0; cite that deposit and INEI SIRTOD when reusing the empirical data. No additional software license is assigned by this update. This package contains code, data and numerical outputs; it does not include the manuscript.

The `code/simulation_V1.R` and `code/simulation_V2.R` files retain their archived content. Publication preparation changed only paths in the empirical and controlled-analysis scripts and relative-path reporting in the verification log. The SHA-256 manifest identifies the packaged files.
