# VERSION ORIGINAL DEL CODIGO DE APLICACION; NO DIFFIT BIBLIOGRAFICO.
############################################################
# MONTE CARLO TUCKER3 PARA ARTICULO
# COMPARACION ENTRE DIFFIT Y MULTIWAY SCREE PLOT
# PROGRAMA AUTONOMO: SIMULACION, ANALISIS Y EXPORTACION
############################################################

# Instalar una sola vez: install.packages("openxlsx")
# Abra este archivo en RStudio y ejecute su contenido completo.
# Todas las funciones estan definidas aqui; no se leen otros scripts.
if (!requireNamespace("openxlsx", quietly = TRUE)) {
  stop('Falta openxlsx. Ejecute install.packages("openxlsx") y vuelva a intentar.')
}

# Exporta objetos en memoria, sin CSV intermedios.
exportar_excel <- function(tablas, destino) {
  wb <- openxlsx::createWorkbook()
  encabezado <- openxlsx::createStyle(
    fgFill = "#243D59", fontColour = "#FFFFFF",
    textDecoration = "bold", wrapText = TRUE
  )

  for (hoja in names(tablas)) {
    # aggregate() puede devolver columnas matriciales: expandirlas para Excel.
    datos <- do.call(data.frame, c(unclass(tablas[[hoja]]), check.names = FALSE))
    if (nrow(datos) > 1048575L || ncol(datos) > 16384L) {
      stop("La hoja excede los limites de Excel: ", hoja)
    }
    infinitos <- lapply(datos, function(x) {
      if (is.numeric(x)) which(is.infinite(x)) else integer(0)
    })
    valores_inf <- Map(function(x, filas) as.character(x[filas]), datos, infinitos)
    for (j in seq_along(datos)) datos[[j]][infinitos[[j]]] <- NA

    openxlsx::addWorksheet(wb, hoja, gridLines = FALSE)
    openxlsx::writeData(
      wb, hoja, datos, headerStyle = encabezado,
      withFilter = nrow(datos) > 0, keepNA = FALSE
    )
    # Inf/-Inf como texto; los restantes valores conservan su tipo numerico.
    for (j in which(lengths(infinitos) > 0L)) {
      for (k in seq_along(infinitos[[j]])) {
        openxlsx::writeData(
          wb, hoja, valores_inf[[j]][k],
          startRow = infinitos[[j]][k] + 1L, startCol = j, colNames = FALSE
        )
      }
    }
    openxlsx::freezePane(wb, hoja, firstRow = TRUE)
    openxlsx::setRowHeights(wb, hoja, rows = 1, heights = 60)
    openxlsx::setColWidths(
      wb, hoja, cols = seq_along(datos),
      widths = pmin(38, pmax(18, nchar(names(datos)) * 0.8))
    )
  }
  openxlsx::setColWidths(wb, "Resumen", cols = 1:2, widths = c(28, 80))
  openxlsx::saveWorkbook(wb, destino, overwrite = TRUE)
  invisible(destino)
}

############################################################
# 1. CONFIGURACION REPRODUCIBLE
############################################################

MC_SEED <- as.integer(Sys.getenv("MC_SEED", "2026"))
N_REP <- as.integer(Sys.getenv("N_REP", "50")) ####Aquí es el número de repeticiones############################################################
N_STARTS_ALS <- as.integer(Sys.getenv("N_STARTS_ALS", "20"))
MAX_ITER_ALS <- as.integer(Sys.getenv("MAX_ITER_ALS", "500"))
TOL_ALS <- as.numeric(Sys.getenv("TOL_ALS", "1e-7"))
SAVE_SIMULATED_ARRAYS <- identical(tolower(Sys.getenv("SAVE_SIMULATED_ARRAYS", "false")), "true")

set.seed(MC_SEED)

# Una carpeta nueva por ejecucion: nunca mezclar resultados antiguos y corregidos.
RUN_MODE <- Sys.getenv("RUN_MODE", "full")
stopifnot(RUN_MODE %in% c("full", "pilot"), N_REP >= 2,
          N_STARTS_ALS >= 1, MAX_ITER_ALS >= 1, TOL_ALS > 0)
output_dir <- Sys.getenv("MC_OUTPUT_DIR", file.path(getwd(),
  paste0("resultados_version_original_aplicacion_", RUN_MODE, "_", format(Sys.time(), "%Y%m%d_%H%M%S"))))
if (dir.exists(output_dir)) stop("La carpeta de salida ya existe; elija una nueva.")
if (!dir.create(output_dir, recursive = TRUE)) {
  stop("No se pudo crear la carpeta de salida: ", output_dir)
}
if (!dir.create(file.path(output_dir, "modelos_por_replica"))) {
  stop("No se pudo crear la carpeta de modelos por replica.")
}

cat("Semilla Monte Carlo:", MC_SEED, "\n")
cat("Replicas por escenario:", N_REP, "\n")
cat("Inicios ALS por modelo:", N_STARTS_ALS, "\n")
cat("Tolerancia ALS:", TOL_ALS, "\n")
cat("Iteraciones maximas ALS:", MAX_ITER_ALS, "\n")

############################################################
# 2. PARAMETROS DEL DISENO
############################################################

tam_list <- list(
  c(50, 10, 5),
  c(100, 10, 5),
  c(25, 25, 25)
)

core_list <- list(
  c(2, 2, 2),
  c(3, 2, 2),
  c(3, 3, 3)
)

error_list <- c(14, 39, 59)
n_grupos_list <- c(2, 3, 4)

separacion_grupos <- 3
sd_intragrupo <- 0.40

############################################################
# 3. DISENO EXPERIMENTAL ANIDADO
############################################################

base_diseno <- expand.grid(
  id_tam = seq_along(tam_list),
  id_core = seq_along(core_list),
  id_error = seq_along(error_list),
  stringsAsFactors = FALSE
)

diseno_aleatorio <- cbind(
  base_diseno,
  patron = "aleatorio",
  n_grupos = NA_integer_
)

diseno_agrupado <- do.call(
  rbind,
  lapply(n_grupos_list, function(g) {
    cbind(base_diseno, patron = "agrupado", n_grupos = g)
  })
)

escenarios <- rbind(diseno_aleatorio, diseno_agrupado)
escenarios$id_escenario <- seq_len(nrow(escenarios))
# Piloto: las tres dimensiones y ambos patrones; no es evidencia publicable.
if (RUN_MODE == "pilot") escenarios <- escenarios[
  escenarios$id_tam == 1 & escenarios$id_error == 1 &
  (escenarios$patron == "aleatorio" | escenarios$n_grupos == 2), ]
escenarios <- escenarios[!is.na(escenarios$id_escenario), ]

diseno <- merge(
  escenarios,
  data.frame(rep = seq_len(N_REP)),
  by = NULL
)
diseno <- diseno[order(diseno$id_escenario, diseno$rep), ]
rownames(diseno) <- NULL
diseno$id_sim <- seq_len(nrow(diseno))

cat("Escenarios factoriales:", nrow(escenarios), "\n")
cat("Simulaciones totales:", nrow(diseno), "\n")

############################################################
# 4. FUNCIONES AUXILIARES
############################################################

generar_matriz_aleatoria <- function(n, r) {
  matrix(rnorm(n * r), nrow = n, ncol = r)
}

generar_matriz_agrupada <- function(n, r, n_grupos,
                                    separacion = 3,
                                    sd_intra = 0.4) {
  grupos <- rep(seq_len(n_grupos), length.out = n)
  grupos <- sample(grupos, size = n, replace = FALSE)

  centroides <- matrix(
    rnorm(n_grupos * r, mean = 0, sd = separacion),
    nrow = n_grupos,
    ncol = r
  )

  M <- matrix(NA_real_, nrow = n, ncol = r)
  for (i in seq_len(n)) {
    M[i, ] <- centroides[grupos[i], ] + rnorm(r, mean = 0, sd = sd_intra)
  }

  list(M = M, grupos = grupos, centroides = centroides)
}

ortogonalizar_columnas <- function(M, r = ncol(M)) {
  qr.Q(qr(M))[, seq_len(r), drop = FALSE]
}

crear_inicio_aleatorio <- function(I, J, K, p, q, r) {
  list(
    A = ortogonalizar_columnas(matrix(rnorm(I * p), I, p), p),
    B = ortogonalizar_columnas(matrix(rnorm(J * q), J, q), q),
    C = ortogonalizar_columnas(matrix(rnorm(K * r), K, r), r)
  )
}

############################################################
# 5. MATRICIZACION Y PRODUCTOS MULTILINEALES
############################################################

matricizar_modo1 <- function(X) matrix(X, nrow = dim(X)[1])

matricizar_modo2 <- function(X) {
  matrix(aperm(X, c(2, 1, 3)), nrow = dim(X)[2])
}

matricizar_modo3 <- function(X) {
  matrix(aperm(X, c(3, 1, 2)), nrow = dim(X)[3])
}

producto_modo <- function(X, M, mode) {
  stopifnot(length(mode) == 1L, mode %in% 1:3, length(dim(X)) == 3L)
  orden <- c(mode, setdiff(1:3, mode))
  dimensiones <- dim(X)[orden]
  stopifnot(ncol(M) == dimensiones[1])
  matricizado <- matrix(aperm(X, orden), nrow = dimensiones[1])
  producto <- array(M %*% matricizado, dim = c(nrow(M), dimensiones[-1]))
  aperm(producto, order(orden))
}

############################################################
# 6. GENERACION DEL TENSOR Y DEL ERROR
############################################################

generar_core_simple <- function(P, Q, R) {
  G <- array(0, dim = c(P, Q, R))
  for (p in seq_len(P)) {
    q <- min(p, Q)
    r <- min(p, R)
    # Para (3,2,2), una celda independiente evita fusionar componentes 2 y 3.
    if (P == 3 && Q == 2 && R == 2 && p == 3) { q <- 1; r <- 2 }
    G[p, q, r] <- 1
  }
  stopifnot(all(rangos_multilineales(G) == c(P, Q, R)))
  G
}

rangos_multilineales <- function(X) {
  vapply(list(matricizar_modo1(X), matricizar_modo2(X), matricizar_modo3(X)),
    function(M) { d <- svd(M, nu=0, nv=0)$d; sum(d > max(d) * 1e-10) }, integer(1))
}

construir_tensor_tucker <- function(A, B, C, G) {
  X <- producto_modo(G, A, 1)
  X <- producto_modo(X, B, 2)
  X <- producto_modo(X, C, 3)
  X
}

agregar_error_controlado <- function(X_true, error_pct) {
  pi_error <- error_pct / 100
  N <- array(rnorm(length(X_true)), dim = dim(X_true))

  SS_estruct <- sum(X_true^2)
  SS_N <- sum(N^2)
  N <- N * sqrt(SS_estruct / SS_N)

  e <- sqrt(pi_error / (1 - pi_error))
  E <- e * N
  X <- X_true + E

  SS_error <- sum(E^2)
  SS_total_sin_cruce <- SS_estruct + SS_error

  list(
    X = X,
    E = E,
    e = e,
    SS_estruct = SS_estruct,
    SS_error = SS_error,
    SS_total_sin_cruce = SS_total_sin_cruce,
    error_pct_obtenido = 100 * SS_error / SS_total_sin_cruce,
    error_pct_en_X = 100 * SS_error / sum(X^2)
  )
}

############################################################
# 7. AJUSTE TUCKER3 POR ALS/HOOI CON INICIOS MULTIPLES
############################################################

calcular_ajuste_tucker <- function(X, A, B, C) {
  G <- producto_modo(X, t(A), 1)
  G <- producto_modo(G, t(B), 2)
  G <- producto_modo(G, t(C), 3)

  Xhat <- producto_modo(G, A, 1)
  Xhat <- producto_modo(Xhat, B, 2)
  Xhat <- producto_modo(Xhat, C, 3)

  SSX <- sum(X^2)
  SCE <- sum((X - Xhat)^2)
  FIT <- 100 * (1 - SCE / SSX)

  list(G = G, Xhat = Xhat, SCE = SCE, FIT = FIT, prop_residual = SCE / SSX)
}

inicio_hosvd <- function(X, p, q, r) {
  list(
    A = svd(matricizar_modo1(X), nu = p, nv = 0)$u[, seq_len(p), drop = FALSE],
    B = svd(matricizar_modo2(X), nu = q, nv = 0)$u[, seq_len(q), drop = FALSE],
    C = svd(matricizar_modo3(X), nu = r, nv = 0)$u[, seq_len(r), drop = FALSE]
  )
}

ajustar_tucker_als_un_inicio <- function(X, p, q, r, inicio,
                                         max_iter = 500,
                                         tol = 1e-7) {
  A <- inicio$A
  B <- inicio$B
  C <- inicio$C
  X1 <- matricizar_modo1(X)
  X2 <- matricizar_modo2(X)
  X3 <- matricizar_modo3(X)
  fit_anterior <- -Inf
  convergio <- FALSE

  for (iter in seq_len(max_iter)) {
    Z1 <- kronecker(C, B)
    A <- svd(X1 %*% Z1, nu = p, nv = 0)$u[, seq_len(p), drop = FALSE]

    Z2 <- kronecker(C, A)
    B <- svd(X2 %*% Z2, nu = q, nv = 0)$u[, seq_len(q), drop = FALSE]

    Z3 <- kronecker(B, A)
    C <- svd(X3 %*% Z3, nu = r, nv = 0)$u[, seq_len(r), drop = FALSE]

    ajuste <- calcular_ajuste_tucker(X, A, B, C)
    mejora <- ajuste$FIT - fit_anterior

    if (is.finite(fit_anterior) && abs(mejora) < tol) {
      convergio <- TRUE
      break
    }

    fit_anterior <- ajuste$FIT
  }

  ajuste$A <- A
  ajuste$B <- B
  ajuste$C <- C
  ajuste$iter <- iter
  ajuste$convergio <- convergio
  ajuste
}

ajustar_tucker_als <- function(X, p, q, r,
                               n_starts = 20,
                               max_iter = 500,
                               tol = 1e-7) {
  d <- dim(X)
  inicios <- vector("list", n_starts)
  inicios[[1]] <- inicio_hosvd(X, p, q, r)

  if (n_starts > 1) {
    for (s in 2:n_starts) {
      inicios[[s]] <- crear_inicio_aleatorio(d[1], d[2], d[3], p, q, r)
    }
  }

  ajustes <- vector("list", n_starts)
  for (s in seq_len(n_starts)) {
    ajustes[[s]] <- ajustar_tucker_als_un_inicio(
      X, p, q, r, inicios[[s]],
      max_iter = max_iter,
      tol = tol
    )
    ajustes[[s]]$start <- s
  }

  fits <- vapply(ajustes, function(z) z$FIT, numeric(1))
  mejor <- ajustes[[which.max(fits)]]
  mejor$fit_por_inicio <- fits
  mejor$n_starts <- n_starts
  mejor
}

############################################################
# 8. CONSTRUCCION DE LA TABLA DE MODELOS CANDIDATOS
############################################################

filtrar_modelos_utiles <- function(SPM) {
  SPM[SPM$P * SPM$Q >= SPM$R &
        SPM$P * SPM$R >= SPM$Q &
        SPM$Q * SPM$R >= SPM$P, , drop = FALSE]
}

construir_SPM <- function(X, p_max, q_max, r_max,
                          n_starts = 20,
                          max_iter = 500,
                          tol = 1e-7) {
  combinaciones <- expand.grid(P = 1:p_max, Q = 1:q_max, R = 1:r_max)
  combinaciones <- filtrar_modelos_utiles(combinaciones)

  SPM <- data.frame(
    P = integer(nrow(combinaciones)),
    Q = integer(nrow(combinaciones)),
    R = integer(nrow(combinaciones)),
    S = integer(nrow(combinaciones)),
    SCE = numeric(nrow(combinaciones)),
    FIT = numeric(nrow(combinaciones)),
    prop_residual = numeric(nrow(combinaciones)),
    convergio = logical(nrow(combinaciones)),
    iter = integer(nrow(combinaciones)),
    mejor_inicio = integer(nrow(combinaciones))
  )

  for (i in seq_len(nrow(combinaciones))) {
    p <- combinaciones$P[i]
    q <- combinaciones$Q[i]
    r <- combinaciones$R[i]

    ajuste <- ajustar_tucker_als(
      X, p, q, r,
      n_starts = n_starts,
      max_iter = max_iter,
      tol = tol
    )

    SPM$P[i] <- p
    SPM$Q[i] <- q
    SPM$R[i] <- r
    SPM$S[i] <- p + q + r
    SPM$SCE[i] <- ajuste$SCE
    SPM$FIT[i] <- ajuste$FIT
    SPM$prop_residual[i] <- ajuste$prop_residual
    SPM$convergio[i] <- ajuste$convergio
    SPM$iter[i] <- ajuste$iter
    SPM$mejor_inicio[i] <- ajuste$start
  }

  SPM <- SPM[order(SPM$S, SPM$SCE, SPM$P, SPM$Q, SPM$R), ]
  rownames(SPM) <- NULL
  SPM
}

############################################################
# 9. CRITERIOS DE SELECCION
############################################################

obtener_scree_multiway <- function(SPM) {
  SCEmin <- aggregate(SCE ~ S, data = SPM, FUN = min)
  FITmax <- aggregate(FIT ~ S, data = SPM, FUN = max)
  tabla <- merge(SCEmin, FITmax, by = "S")
  tabla <- tabla[order(tabla$S), ]
  rownames(tabla) <- NULL
  tabla
}

obtener_mejor_modelo_por_S <- function(SPM) {
  S_vals <- sort(unique(SPM$S))
  salida <- vector("list", length(S_vals))

  for (i in seq_along(S_vals)) {
    sub <- SPM[SPM$S == S_vals[i], , drop = FALSE]
    sub <- sub[order(sub$SCE, -sub$FIT, sub$P, sub$Q, sub$R), , drop = FALSE]
    salida[[i]] <- sub[1, , drop = FALSE]
  }

  out <- do.call(rbind, salida)
  rownames(out) <- NULL
  out
}

# VERSION ORIGINAL APLICACION: reproduce el selector del Excel anterior.
# No significa DIFFIT original bibliografico.
seleccionar_multiway_scree <- function(tabla_scree) {
  curvatura <- rep(NA_real_, nrow(tabla_scree))
  if (nrow(tabla_scree) >= 3L)
    curvatura[2L:(nrow(tabla_scree)-1L)] <- diff(diff(tabla_scree$FIT))
  idx <- if (all(is.na(curvatura))) which.max(tabla_scree$FIT) else which.max(abs(curvatura))
  list(s_sel=tabla_scree$S[idx], idx=idx, valor_criterio=abs(curvatura[idx]))
}

mejor_modelo_por_s_fit <- function(SPM) {
  s_vals <- sort(unique(SPM$S))
  out <- vector("list", length(s_vals))

  for (i in seq_along(s_vals)) {
    sub <- SPM[SPM$S == s_vals[i], , drop = FALSE]
    sub <- sub[order(-sub$FIT, sub$SCE, sub$P, sub$Q, sub$R), , drop = FALSE]
    out[[i]] <- sub[1, , drop = FALSE]
  }

  best <- do.call(rbind, out)
  rownames(best) <- NULL
  best
}

calcular_dif <- function(best_by_s) {
  best_by_s <- best_by_s[order(best_by_s$S), , drop = FALSE]
  best_by_s$dif <- c(best_by_s$FIT[1], diff(best_by_s$FIT))
  best_by_s
}

obtener_maximos_secuenciales <- function(best_by_s) {
  n <- nrow(best_by_s)
  es_max_seq <- rep(FALSE, n)

  for (i in seq_len(n)) {
    if (i == n) {
      es_max_seq[i] <- TRUE
    } else {
      es_max_seq[i] <- best_by_s$dif[i] >= max(best_by_s$dif[(i + 1):n], na.rm = TRUE)
    }
  }

  dift <- best_by_s[es_max_seq, , drop = FALSE]
  rownames(dift) <- NULL
  dift$salience <- NA_real_

  if (nrow(dift) >= 2) {
    for (i in seq_len(nrow(dift) - 1)) {
      dift$salience[i] <- ifelse(abs(dift$dif[i + 1]) < 1e-12,
                                 Inf,
                                 dift$dif[i] / dift$dif[i + 1])
    }
  }

  dift
}

# Variante del programa macroeconomico anterior: sin primer incremento ni umbral.
seleccionar_diffit <- function(SPM, I, J, K) {
  best <- obtener_mejor_modelo_por_S(SPM)
  mejora <- head(best$SCE,-1L)-tail(best$SCE,-1L)
  puntaje <- rep(NA_real_,nrow(best))
  if (length(mejora)>=2L) for(i in seq_len(length(mejora)-1L)) {
    denom <- max(mejora[(i+1L):length(mejora)],na.rm=TRUE)
    puntaje[i+1L] <- if(is.finite(denom) && denom>0) mejora[i]/denom else NA_real_
  }
  idx <- if(all(is.na(puntaje))) which.min(best$SCE) else which.max(puntaje)
  list(s_c=best$S[idx],modelo_final=best[idx,,drop=FALSE],
       valor_diffit=puntaje[idx],dif_seleccionado=c(NA_real_,diff(best$FIT))[idx],
       umbral_diffit_pct=NA_real_)
}

############################################################
# 10. METRICAS DE DESEMPENO
############################################################

calcular_metricas <- function(P_sel, Q_sel, R_sel, fit_sel, SCE_sel,
                              P_real, Q_real, R_real, fit_true) {
  S_sel <- P_sel + Q_sel + R_sel
  S_real <- P_real + Q_real + R_real

  data.frame(
    P_sel = P_sel,
    Q_sel = Q_sel,
    R_sel = R_sel,
    S_sel = S_sel,
    fit = fit_sel,
    SCE = SCE_sel,
    prop_residual = 1 - fit_sel / 100,
    acierto = as.integer(P_sel == P_real & Q_sel == Q_real & R_sel == R_real),
    acierto_P = as.integer(P_sel == P_real),
    acierto_Q = as.integer(Q_sel == Q_real),
    acierto_R = as.integer(R_sel == R_real),
    error_abs_total = abs(P_sel - P_real) + abs(Q_sel - Q_real) + abs(R_sel - R_real),
    error_cuadratico = (P_sel - P_real)^2 + (Q_sel - Q_real)^2 + (R_sel - R_real)^2,
    sesgo_S = S_sel - S_real,
    error_abs_S = abs(S_sel - S_real),
    sobreseleccion = as.integer(S_sel > S_real),
    subseleccion = as.integer(S_sel < S_real),
    seleccion_exacta_S = as.integer(S_sel == S_real),
    delta_fit_vs_verdadero = fit_sel - fit_true
  )
}

mc_resumen_binario <- function(x) {
  n <- length(x)
  p <- mean(x)
  se <- sqrt(p * (1 - p) / n)
  data.frame(
    n = n,
    tasa_pct = 100 * p,
    error_mc_pct = 100 * se,
    ic95_inf_pct = 100 * ((p+1.96^2/(2*n))-1.96*sqrt(p*(1-p)/n+1.96^2/(4*n^2)))/(1+1.96^2/n),
    ic95_sup_pct = 100 * ((p+1.96^2/(2*n))+1.96*sqrt(p*(1-p)/n+1.96^2/(4*n^2)))/(1+1.96^2/n)
  )
}

resumir_por_grupo <- function(data, vars_grupo) {
  if (length(vars_grupo) == 0) {
    data$.grupo_global <- "global"
    vars_grupo <- ".grupo_global"
  }

  split_data <- split(data, lapply(data[vars_grupo], function(x) {
    x <- as.character(x); x[is.na(x)] <- "no_aplica"; x
  }), drop = TRUE)

  out <- lapply(names(split_data), function(nm) {
    z <- split_data[[nm]]
    base <- z[1, vars_grupo, drop = FALSE]
    scree <- mc_resumen_binario(z$acierto_scree)
    diffit <- mc_resumen_binario(z$acierto_diffit)

    data.frame(
      base,
      n = nrow(z),
      acierto_scree_pct = 100 * mean(z$acierto_scree),
      error_mc_acierto_scree = 100 * sqrt(mean(z$acierto_scree) * (1 - mean(z$acierto_scree)) / nrow(z)),
      acierto_diffit_pct = 100 * mean(z$acierto_diffit),
      error_mc_acierto_diffit = 100 * sqrt(mean(z$acierto_diffit) * (1 - mean(z$acierto_diffit)) / nrow(z)),
      ic95_inf_scree_pct = scree$ic95_inf_pct,
      ic95_sup_scree_pct = scree$ic95_sup_pct,
      ic95_inf_diffit_pct = diffit$ic95_inf_pct,
      ic95_sup_diffit_pct = diffit$ic95_sup_pct,
      aciertoP_scree_pct = 100*mean(z$aciertoP_scree),
      aciertoQ_scree_pct = 100*mean(z$aciertoQ_scree),
      aciertoR_scree_pct = 100*mean(z$aciertoR_scree),
      aciertoP_diffit_pct = 100*mean(z$aciertoP_diffit),
      aciertoQ_diffit_pct = 100*mean(z$aciertoQ_diffit),
      aciertoR_diffit_pct = 100*mean(z$aciertoR_diffit),
      fit_scree_prom = mean(z$fit_scree),
      fit_diffit_prom = mean(z$fit_diffit),
      SCE_scree_prom = mean(z$SCE_scree),
      SCE_diffit_prom = mean(z$SCE_diffit),
      sobreseleccion_scree_pct = 100 * mean(z$sobreseleccion_scree),
      sobreseleccion_diffit_pct = 100 * mean(z$sobreseleccion_diffit),
      subseleccion_scree_pct = 100 * mean(z$subseleccion_scree),
      subseleccion_diffit_pct = 100 * mean(z$subseleccion_diffit),
      error_abs_scree_prom = mean(z$error_abs_scree),
      error_abs_diffit_prom = mean(z$error_abs_diffit),
      sesgo_scree_prom = mean(z$sesgo_scree),
      sesgo_diffit_prom = mean(z$sesgo_diffit),
      coincidencia_pct = 100 * mean(z$coincide_criterios)
    )
  })

  salida <- do.call(rbind, out)
  rownames(salida) <- NULL
  salida
}

mcnemar_por_grupo <- function(data, vars_grupo) {
  if (length(vars_grupo) == 0) {
    data$.grupo_global <- "global"
    vars_grupo <- ".grupo_global"
  }

  split_data <- split(data, lapply(data[vars_grupo], function(x) {
    x <- as.character(x); x[is.na(x)] <- "no_aplica"; x
  }), drop = TRUE)

  out <- lapply(names(split_data), function(nm) {
    z <- split_data[[nm]]
    base <- z[1, vars_grupo, drop = FALSE]

    b <- sum(z$acierto_scree == 1 & z$acierto_diffit == 0)
    c <- sum(z$acierto_scree == 0 & z$acierto_diffit == 1)
    n <- nrow(z)
    d <- z$acierto_scree - z$acierto_diffit
    dif <- mean(d)
    se <- sd(d) / sqrt(n)

    # McNemar exacto, adecuado tambien con pocos pares discordantes.
    p_val <- if ((b + c) == 0) 1 else binom.test(b, b + c, p = 0.5)$p.value

    data.frame(
      base,
      n = n,
      scree_acierta_diffit_no = b,
      diffit_acierta_scree_no = c,
      diferencia_tasas_pct = 100 * dif,
      ic95_inf_dif_pct = 100 * max(-1, dif - 1.96 * se),
      ic95_sup_dif_pct = 100 * min(1, dif + 1.96 * se),
      tipo_ic = "Wald pareado aproximado; degenerado si varianza cero",
      p_mcnemar = p_val
    )
  })

  salida <- do.call(rbind, out)
  rownames(salida) <- NULL
  salida
}

############################################################
# 11. OBJETOS DE SALIDA
############################################################

filas_generacion <- vector("list", nrow(diseno))
filas_resultados <- vector("list", nrow(diseno))
datos_simulados <- if (SAVE_SIMULATED_ARRAYS) vector("list", nrow(diseno)) else NULL

############################################################
# 12. GENERACION Y EVALUACION MONTE CARLO
############################################################

for (i in seq_len(nrow(diseno))) {
  cat("Simulacion", i, "de", nrow(diseno), "\n")

  dims <- tam_list[[diseno$id_tam[i]]]
  core <- core_list[[diseno$id_core[i]]]
  error_pct <- error_list[diseno$id_error[i]]
  patron <- diseno$patron[i]
  n_grupos <- diseno$n_grupos[i]

  I <- dims[1]; J <- dims[2]; K <- dims[3]
  P_real <- core[1]; Q_real <- core[2]; R_real <- core[3]
  S_real <- P_real + Q_real + R_real

  if (patron == "aleatorio") {
    A <- generar_matriz_aleatoria(I, P_real)
    grupos_A <- rep(NA_integer_, I)
  } else {
    genA <- generar_matriz_agrupada(
      n = I,
      r = P_real,
      n_grupos = n_grupos,
      separacion = separacion_grupos,
      sd_intra = sd_intragrupo
    )
    A <- genA$M
    grupos_A <- genA$grupos
  }

  B <- ortogonalizar_columnas(generar_matriz_aleatoria(J, Q_real), Q_real)
  C <- ortogonalizar_columnas(generar_matriz_aleatoria(K, R_real), R_real)
  G <- generar_core_simple(P_real, Q_real, R_real)
  X_true <- construir_tensor_tucker(A, B, C, G)
  rango_efectivo <- rangos_multilineales(X_true)
  if (!all(rango_efectivo == core)) stop("Rango efectivo distinto del declarado")
  ruido <- agregar_error_controlado(X_true, error_pct)
  X <- ruido$X

  p_max <- min(4, I)
  q_max <- min(4, J)
  r_max <- min(4, K)

  ajuste_verdadero <- ajustar_tucker_als(
    X, P_real, Q_real, R_real,
    n_starts = N_STARTS_ALS,
    max_iter = MAX_ITER_ALS,
    tol = TOL_ALS
  )
  fit_modelo_verdadero <- ajuste_verdadero$FIT

  SPM <- construir_SPM(
    X, p_max, q_max, r_max,
    n_starts = N_STARTS_ALS,
    max_iter = MAX_ITER_ALS,
    tol = TOL_ALS
  )

  tabla_scree <- obtener_scree_multiway(SPM)
  saveRDS(SPM, file.path(output_dir, "modelos_por_replica",
                         sprintf("SPM_%05d.rds", diseno$id_sim[i])))
  mejor_por_S <- obtener_mejor_modelo_por_S(SPM)
  sel_scree <- seleccionar_multiway_scree(tabla_scree)
  modelo_scree <- mejor_por_S[mejor_por_S$S == sel_scree$s_sel, , drop = FALSE]

  res_diffit <- seleccionar_diffit(SPM, I, J, K)
  modelo_diffit <- res_diffit$modelo_final

  met_scree <- calcular_metricas(
    modelo_scree$P, modelo_scree$Q, modelo_scree$R,
    modelo_scree$FIT, modelo_scree$SCE,
    P_real, Q_real, R_real, fit_modelo_verdadero
  )

  met_diffit <- calcular_metricas(
    modelo_diffit$P, modelo_diffit$Q, modelo_diffit$R,
    modelo_diffit$FIT, modelo_diffit$SCE,
    P_real, Q_real, R_real, fit_modelo_verdadero
  )

  filas_generacion[[i]] <- data.frame(
    id_sim = diseno$id_sim[i],
    id_escenario = diseno$id_escenario[i],
    rep = diseno$rep[i],
    patron = patron,
    n_grupos = ifelse(is.na(n_grupos), NA_integer_, n_grupos),
    I = I, J = J, K = K,
    P_real = P_real, Q_real = Q_real, R_real = R_real,
    S_real = S_real,
    rango_P = rango_efectivo[1], rango_Q = rango_efectivo[2], rango_R = rango_efectivo[3],
    error_pct_deseado = error_pct,
    error_pct_obtenido = ruido$error_pct_obtenido,
    error_pct_en_X = ruido$error_pct_en_X,
    e_error = ruido$e,
    SS_estruct = ruido$SS_estruct,
    SS_error = ruido$SS_error,
    SS_total_sin_cruce = ruido$SS_total_sin_cruce,
    fit_modelo_verdadero = fit_modelo_verdadero,
    convergio_modelo_verdadero = ajuste_verdadero$convergio,
    iter_modelo_verdadero = ajuste_verdadero$iter
  )

  filas_resultados[[i]] <- data.frame(
    id_sim = diseno$id_sim[i],
    id_escenario = diseno$id_escenario[i],
    rep = diseno$rep[i],
    patron = patron,
    n_grupos = ifelse(is.na(n_grupos), NA_integer_, n_grupos),
    I = I, J = J, K = K,
    tamano = paste(I, J, K, sep = "x"),
    P_real = P_real, Q_real = Q_real, R_real = R_real,
    core_real = paste0("P", P_real, "_Q", Q_real, "_R", R_real),
    S_real = S_real,
    error_pct = error_pct,
    P_scree = met_scree$P_sel,
    Q_scree = met_scree$Q_sel,
    R_scree = met_scree$R_sel,
    S_scree = met_scree$S_sel,
    criterio_scree = sel_scree$valor_criterio,
    fit_scree = met_scree$fit,
    SCE_scree = met_scree$SCE,
    prop_residual_scree = met_scree$prop_residual,
    acierto_scree = met_scree$acierto,
    aciertoP_scree = met_scree$acierto_P,
    aciertoQ_scree = met_scree$acierto_Q,
    aciertoR_scree = met_scree$acierto_R,
    error_abs_scree = met_scree$error_abs_total,
    error_cuad_scree = met_scree$error_cuadratico,
    sesgo_scree = met_scree$sesgo_S,
    error_abs_S_scree = met_scree$error_abs_S,
    sobreseleccion_scree = met_scree$sobreseleccion,
    subseleccion_scree = met_scree$subseleccion,
    seleccion_exacta_S_scree = met_scree$seleccion_exacta_S,
    delta_fit_verdadero_scree = met_scree$delta_fit_vs_verdadero,
    P_diffit = met_diffit$P_sel,
    Q_diffit = met_diffit$Q_sel,
    R_diffit = met_diffit$R_sel,
    S_diffit = met_diffit$S_sel,
    valor_diffit = res_diffit$valor_diffit,
    dif_seleccionado = res_diffit$dif_seleccionado,
    umbral_diffit_pct = res_diffit$umbral_diffit_pct,
    fit_diffit = met_diffit$fit,
    SCE_diffit = met_diffit$SCE,
    prop_residual_diffit = met_diffit$prop_residual,
    acierto_diffit = met_diffit$acierto,
    aciertoP_diffit = met_diffit$acierto_P,
    aciertoQ_diffit = met_diffit$acierto_Q,
    aciertoR_diffit = met_diffit$acierto_R,
    error_abs_diffit = met_diffit$error_abs_total,
    error_cuad_diffit = met_diffit$error_cuadratico,
    sesgo_diffit = met_diffit$sesgo_S,
    error_abs_S_diffit = met_diffit$error_abs_S,
    sobreseleccion_diffit = met_diffit$sobreseleccion,
    subseleccion_diffit = met_diffit$subseleccion,
    seleccion_exacta_S_diffit = met_diffit$seleccion_exacta_S,
    delta_fit_verdadero_diffit = met_diffit$delta_fit_vs_verdadero,
    fit_modelo_verdadero = fit_modelo_verdadero,
    coincide_criterios = as.integer(
      met_scree$P_sel == met_diffit$P_sel &
        met_scree$Q_sel == met_diffit$Q_sel &
        met_scree$R_sel == met_diffit$R_sel
    ),
    convergencia_spm_pct = 100 * mean(SPM$convergio),
    convergio_scree = modelo_scree$convergio,
    convergio_diffit = modelo_diffit$convergio,
    iter_spm_prom = mean(SPM$iter)
  )

  if (SAVE_SIMULATED_ARRAYS) {
    datos_simulados[[i]] <- list(
      id_sim = diseno$id_sim[i],
      grupos_A = grupos_A,
      A = A, B = B, C = C, G = G,
      X_true = X_true, E = ruido$E, X = X
    )
  }
}

############################################################
# 13. TABLAS PARA MANUSCRITO Y MATERIAL SUPLEMENTARIO
############################################################

resumen_generacion <- do.call(rbind, filas_generacion)
resultados <- do.call(rbind, filas_resultados)
rm(filas_generacion, filas_resultados)

tabla_global <- resumir_por_grupo(resultados, character(0))
tabla_patron <- resumir_por_grupo(resultados, "patron")
tabla_error_patron <- resumir_por_grupo(resultados, c("patron", "error_pct"))
tabla_tamano <- resumir_por_grupo(resultados, "tamano")
tabla_core <- resumir_por_grupo(resultados, "core_real")
tabla_grupos <- resumir_por_grupo(resultados[resultados$patron == "agrupado", ], "n_grupos")

tabla_celda_completa <- resumir_por_grupo(
  resultados,
  c("patron", "n_grupos", "tamano", "core_real", "error_pct")
)

mcnemar_global <- mcnemar_por_grupo(resultados, character(0))
mcnemar_patron <- mcnemar_por_grupo(resultados, "patron")
mcnemar_error_patron <- mcnemar_por_grupo(resultados, c("patron", "error_pct"))
mcnemar_celda_completa <- mcnemar_por_grupo(
  resultados,
  c("patron", "n_grupos", "tamano", "core_real", "error_pct")
)

tabla_error_generado <- aggregate(
  cbind(error_pct_obtenido, error_pct_en_X) ~ patron + error_pct_deseado,
  data = resumen_generacion,
  FUN = function(x) c(media = mean(x), sd = sd(x), min = min(x), max = max(x))
)

resultados_largo <- rbind(
  data.frame(
    id_sim = resultados$id_sim,
    patron = resultados$patron,
    n_grupos = resultados$n_grupos,
    tamano = resultados$tamano,
    core_real = resultados$core_real,
    error_pct = resultados$error_pct,
    metodo = "Scree",
    acierto = resultados$acierto_scree,
    sobreseleccion = resultados$sobreseleccion_scree,
    subseleccion = resultados$subseleccion_scree,
    fit = resultados$fit_scree,
    S_sel = resultados$S_scree
  ),
  data.frame(
    id_sim = resultados$id_sim,
    patron = resultados$patron,
    n_grupos = resultados$n_grupos,
    tamano = resultados$tamano,
    core_real = resultados$core_real,
    error_pct = resultados$error_pct,
    metodo = "DIFFIT",
    acierto = resultados$acierto_diffit,
    sobreseleccion = resultados$sobreseleccion_diffit,
    subseleccion = resultados$subseleccion_diffit,
    fit = resultados$fit_diffit,
    S_sel = resultados$S_diffit
  )
)

# Inferencia exploratoria: sandwich agrupado por tensor (id_sim), HC1.
# No reportar inferencia convencional si hay separacion o falta de convergencia.
logistica_pareada <- function(data) {
  if (any(vapply(data[c("metodo","patron","error_pct","tamano","core_real")],
                 function(x) length(unique(x)) < 2, logical(1))))
    return(data.frame(estado="No estimable: piloto o factores sin variacion"))
  fit <- glm(acierto ~ metodo * patron + factor(error_pct) + tamano + core_real,
             data = data, family = binomial())
  if (!fit$converged || anyNA(coef(fit)) || any(abs(coef(fit)) > 20)) {
    return(data.frame(estado="No estimable: convergencia, rango o posible separacion"))
  }
  X <- model.matrix(fit)
  bread <- tryCatch(solve(crossprod(X, X * fit$weights)), error=function(e) NULL)
  if (is.null(bread)) return(data.frame(estado="No estimable: informacion singular"))
  U <- rowsum(X * (data$acierto - fitted(fit)), data$id_sim, reorder=FALSE)
  n <- nrow(X); k <- ncol(X); m <- nrow(U)
  if (m <= 1 || n <= k) return(data.frame(estado="Muestra insuficiente"))
  V <- (m/(m-1))*((n-1)/(n-k)) * bread %*% crossprod(U) %*% bread
  se <- sqrt(pmax(diag(V), 0)); beta <- coef(fit)
  data.frame(termino=names(beta), estimacion=beta, error_estandar_cluster=se,
    odds_ratio=exp(beta), ic95_inf_or=exp(beta-1.96*se),
    ic95_sup_or=exp(beta+1.96*se), p_valor=2*pnorm(-abs(beta/se)),
    estado="Exploratorio; sandwich HC1 agrupado por id_sim", row.names=NULL)
}
tabla_logistica_acierto <- logistica_pareada(resultados_largo)

############################################################
# 14. METADATOS Y EXPORTACION DIRECTA A EXCEL
############################################################

parametros <- list(
  MC_SEED = MC_SEED, N_REP = N_REP, N_STARTS_ALS = N_STARTS_ALS,
  MAX_ITER_ALS = MAX_ITER_ALS, TOL_ALS = TOL_ALS,
  escenarios_factoriales = nrow(escenarios), simulaciones_totales = nrow(diseno),
  separacion_grupos = separacion_grupos, sd_intragrupo = sd_intragrupo,
  software = "R", version_R = as.character(getRversion()),
  version_codigo = "version_original_aplicacion_20260923", modo = RUN_MODE,
  core = "sparse_full_multilinear_rank",
  scree = "segunda_diferencia_simple_fit_absoluta",
  diffit = "variante_aplicacion_sin_incremento_inicial_sin_umbral",
  preprocesamiento = "sin_centrado_ni_escalado", logistica = "cluster_id_sim_HC1"
)
metadata <- data.frame(
  parametro = names(parametros),
  valor = vapply(parametros, as.character, character(1)), row.names = NULL
)

resumen <- data.frame(
  Campo = c("Ejecucion", "Tensores", "Escenarios", "Replicas por escenario",
            "Inicios ALS", "Porcentajes", "Datos ausentes", "Infinitos", "Origen"),
  Valor = c(
    if (RUN_MODE == "pilot") "PILOTO: prueba tecnica, no resultados definitivos"
    else "Simulacion completa",
    nrow(diseno), nrow(escenarios), N_REP, N_STARTS_ALS,
    "Columnas *_pct en escala 0-100", "NA/NaN: celdas vacias",
    "Inf y -Inf se conservan como texto",
    "Resultados calculados en R; no se recalculan al editar Excel"
  )
)

stopifnot(nrow(tabla_celda_completa) == nrow(escenarios))
tablas <- list(
  Resumen = resumen,
  Global = tabla_global,
  Por_patron = tabla_patron,
  Ruido_y_patron = tabla_error_patron,
  Por_tamano = tabla_tamano,
  Por_dimension = tabla_core,
  Por_grupos = tabla_grupos,
  Celdas_completas = tabla_celda_completa,
  McNemar_global = mcnemar_global,
  McNemar_patron = mcnemar_patron,
  McNemar_ruido = mcnemar_error_patron,
  McNemar_celdas = mcnemar_celda_completa,
  Logistica = tabla_logistica_acierto,
  Parametros = metadata,
  Escenarios = escenarios,
  Generacion = resumen_generacion,
  Replicas = resultados,
  Error_generado = tabla_error_generado,
  Formato_largo = resultados_largo,
  Sesion_R = data.frame(Informacion = capture.output(sessionInfo()))
)

# RDS conserva los objetos y su precision para reutilizarlos en R.
saveRDS(
  list(metadata = metadata, resultados = resultados,
       generacion = resumen_generacion, escenarios = escenarios),
  file.path(output_dir, "resultados_numericos.rds")
)
if (SAVE_SIMULATED_ARRAYS) {
  saveRDS(datos_simulados, file.path(output_dir, "datos_simulados.rds"))
}

nombre_excel <- if (RUN_MODE == "pilot") "Resultados_Tucker3_PILOTO.xlsx" else "Resultados_Tucker3.xlsx"
archivo_excel <- exportar_excel(tablas, file.path(output_dir, nombre_excel))
cat("\nExcel guardado:", archivo_excel, "\n")
cat("Hojas principales: Global, Replicas, Celdas_completas, McNemar_global, Logistica.\n")
