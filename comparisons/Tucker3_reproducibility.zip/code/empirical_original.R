##############################
# TUCKER3: COMPARACION DIFFIT Y SCREE MULTIWAY
##############################

##############################
# 1. PAQUETES Y PARAMETROS
##############################

paquetes <- c("readxl", "openxlsx", "ade4", "MASS")
faltantes <- paquetes[
  !vapply(paquetes, requireNamespace, logical(1), quietly = TRUE)
]

if (length(faltantes) > 0L) {
  stop(
    "Faltan los paquetes: ", paste(faltantes, collapse = ", "),
    ". Instalalos con install.packages()."
  )
}

library(readxl)
library(openxlsx)
library(ade4)
library(MASS)

ruta_archivo <- file.path("data", "observed_data.xlsx")

directorio_salida <- dirname(ruta_archivo)
archivo_excel <- file.path(
  directorio_salida,
  "Resultados_Tucker3_comparacion_diffit_scree.xlsx"
)
fila_nombres <- c(
  "AMA", "ANC", "APU", "ARE", "AYA", "CAJ", "CUS", "HUV",
  "HUC", "ICA", "JUN", "LAL", "LAM", "LIM", "LOR", "MMD",
  "MOQ", "PAS", "PIU", "PUN", "SAN", "TAC", "TUM", "UCA"
)

tol <- 1e-8
max_iter <- 500L
min_iter <- 3L
Pmax_usuario <- 6L
Qmax_usuario <- 5L
Rmax_usuario <- 4L

if (!file.exists(ruta_archivo)) {
  stop("No existe el archivo de entrada: ", ruta_archivo)
}

##############################
# 2. FUNCIONES AUXILIARES
##############################

convertir_numerico <- function(x, hoja, columna) {
  if (is.numeric(x)) {
    return(as.numeric(x))
  }

  x_chr <- trimws(as.character(x))
  vacios <- is.na(x_chr) | x_chr == ""
  convertido <- suppressWarnings(as.numeric(x_chr))
  invalidos <- !vacios & is.na(convertido)

  if (any(invalidos)) {
    ejemplos <- head(unique(x_chr[invalidos]), 5L)
    stop(
      "La hoja '", hoja, "', columna '", columna,
      "', contiene valores no numericos: ",
      paste(ejemplos, collapse = ", ")
    )
  }

  convertido
}

matricizar_Xa <- function(lista_matrices) {
  do.call(cbind, lapply(lista_matrices, as.matrix))
}

matricizar_Xb <- function(lista_matrices) {
  do.call(cbind, lapply(lista_matrices, function(m) t(as.matrix(m))))
}

matricizar_Xc <- function(lista_matrices) {
  do.call(rbind, lapply(lista_matrices, function(m) c(as.matrix(m))))
}

reconstruir_desde_Xa <- function(Xa, J, K) {
  if (ncol(Xa) != J * K) {
    stop("Dimension incompatible: ncol(Xa) debe ser J * K.")
  }

  bloques <- lapply(seq_len(K), function(k) {
    inicio <- (k - 1L) * J + 1L
    fin <- k * J
    Xa[, inicio:fin, drop = FALSE]
  })

  list(
    Xb = do.call(cbind, lapply(bloques, t)),
    Xc = do.call(rbind, lapply(bloques, c))
  )
}

diag_safe <- function(x) {
  if (length(x) == 1L) matrix(x, 1L, 1L) else diag(x)
}

rangos_comunes <- function(puntos, flechas) {
  rx <- range(c(puntos[, 1L], flechas[, 1L], 0), finite = TRUE)
  ry <- range(c(puntos[, 2L], flechas[, 2L], 0), finite = TRUE)

  ampliar <- function(r) {
    if (diff(r) == 0) {
      r + c(-1, 1)
    } else {
      r + c(-1, 1) * diff(r) * 0.05
    }
  }

  list(xlim = ampliar(rx), ylim = ampliar(ry))
}

grafico_no_disponible <- function(titulo, mensaje) {
  plot.new()
  title(main = titulo)
  text(0.5, 0.5, mensaje, cex = 1)
  box()
}

##############################
# 3. LECTURA Y VALIDACION
##############################

nombres_hojas <- excel_sheets(ruta_archivo)

if (length(nombres_hojas) == 0L) {
  stop("El libro no contiene hojas legibles.")
}

lista <- setNames(
  lapply(nombres_hojas, function(hoja) {
    df <- as.data.frame(
      read_excel(ruta_archivo, sheet = hoja, col_names = TRUE),
      check.names = FALSE
    )

    if (nrow(df) != length(fila_nombres)) {
      stop(
        "La hoja '", hoja, "' tiene ", nrow(df),
        " filas; se esperaban ", length(fila_nombres), "."
      )
    }

    if (ncol(df) == 0L) {
      stop("La hoja '", hoja, "' no contiene columnas.")
    }

    if (anyNA(colnames(df)) || any(trimws(colnames(df)) == "")) {
      stop("La hoja '", hoja, "' tiene nombres de columna vacios.")
    }

    if (anyDuplicated(colnames(df))) {
      stop("La hoja '", hoja, "' tiene nombres de columna duplicados.")
    }

    df[] <- Map(
      function(x, columna) convertir_numerico(x, hoja, columna),
      df,
      colnames(df)
    )

    if (anyNA(df)) {
      posicion <- which(is.na(as.matrix(df)), arr.ind = TRUE)[1L, ]
      stop(
        "Dato faltante en la hoja '", hoja, "', fila ",
        posicion[1L], ", columna '",
        colnames(df)[posicion[2L]], "'."
      )
    }

    if (any(!is.finite(as.matrix(df)))) {
      stop("La hoja '", hoja, "' contiene valores no finitos.")
    }

    rownames(df) <- fila_nombres
    df
  }),
  nombres_hojas
)

dim_ref <- dim(lista[[1L]])
cols_ref <- colnames(lista[[1L]])

for (i in seq_along(lista)) {
  if (!identical(dim(lista[[i]]), dim_ref)) {
    stop("Las hojas del libro no tienen las mismas dimensiones.")
  }

  if (!identical(colnames(lista[[i]]), cols_ref)) {
    stop("Las hojas no tienen los mismos nombres y orden de columnas.")
  }
}

##############################
# 4. MATRICIZACIONES
##############################

I <- nrow(lista[[1L]])
J <- ncol(lista[[1L]])
K <- length(lista)

if (I < 2L || J < 2L || K < 2L) {
  stop("Tucker3 requiere al menos dos elementos en cada modo.")
}

Xa <- matricizar_Xa(lista)
Xb <- matricizar_Xb(lista)
Xc <- matricizar_Xc(lista)

ind <- fila_nombres
var <- cols_ref
cond <- nombres_hojas

indcond <- unlist(
  lapply(cond, function(h) paste(ind, h, sep = "-")),
  use.names = FALSE
)
varcond <- unlist(
  lapply(cond, function(h) paste(var, h, sep = "-")),
  use.names = FALSE
)
indvar <- unlist(
  lapply(var, function(v) paste(ind, v, sep = "-")),
  use.names = FALSE
)

dimnames(Xa) <- list(ind, varcond)
dimnames(Xb) <- list(var, indcond)
dimnames(Xc) <- list(cond, indvar)

##############################
# 5. PREPROCESAMIENTO
##############################

na <- nrow(Xa)
nb <- nrow(Xb)
nc <- nrow(Xc)

Port <- diag(na) - matrix(1 / na, nrow = na, ncol = na)
Xac <- Port %*% Xa

recons_centrado <- reconstruir_desde_Xa(Xac, J = nb, K = nc)
Xbac <- recons_centrado$Xb
Xcac <- recons_centrado$Xc

normas_j <- rowSums(Xbac^2) / (na * nc)
normas_k <- rowSums(Xcac^2) / (na * nb)

if (
  any(!is.finite(normas_j)) ||
  any(!is.finite(normas_k)) ||
  max(normas_j) <= 0 ||
  max(normas_k) <= 0
) {
  stop("Las normas de preprocesamiento no son positivas y finitas.")
}

umbral_relativo <- sqrt(.Machine$double.eps)
umbral_j <- max(normas_j) * umbral_relativo
umbral_k <- max(normas_k) * umbral_relativo

problemas_j <- normas_j <= umbral_j
problemas_k <- normas_k <= umbral_k

if (any(problemas_j)) {
  stop(
    "Variables con variacion nula o casi nula: ",
    paste(var[problemas_j], collapse = ", ")
  )
}

if (any(problemas_k)) {
  stop(
    "Condiciones con norma nula o casi nula: ",
    paste(cond[problemas_k], collapse = ", ")
  )
}

Wj <- diag(1 / sqrt(normas_j), nrow = nb, ncol = nb)
Wk <- diag(1 / sqrt(normas_k), nrow = nc, ncol = nc)

X1 <- Xac %*% kronecker(Wk, Wj)
recons_norm <- reconstruir_desde_Xa(X1, J = nb, K = nc)
X2 <- recons_norm$Xb
X3 <- recons_norm$Xc

dimnames(X1) <- list(ind, varcond)
dimnames(X2) <- list(var, indcond)
dimnames(X3) <- list(cond, indvar)

SSX <- sum(X1^2)

if (!is.finite(SSX) || SSX <= 0) {
  stop("La suma de cuadrados total no es positiva y finita.")
}

##############################
# 6. MODELOS CANDIDATOS
##############################

Pmax <- min(Pmax_usuario, nrow(X1) - 1L)
Qmax <- min(Qmax_usuario, nrow(X2) - 1L)
Rmax <- min(Rmax_usuario, nrow(X3) - 1L)

Z <- expand.grid(
  P = seq_len(Pmax),
  Q = seq_len(Qmax),
  R = seq_len(Rmax)
)

identificable <- with(
  Z,
  P * Q >= R &
    Q * R >= P &
    P * R >= Q
)
Z <- Z[identificable, , drop = FALSE]
Z$Ncomp <- rowSums(Z[, c("P", "Q", "R"), drop = FALSE])

maxi <- min(Pmax + 1L, (Qmax + 1L) * (Rmax + 1L)) +
  min(Qmax + 1L, (Pmax + 1L) * (Rmax + 1L)) +
  min(Rmax + 1L, (Pmax + 1L) * (Qmax + 1L)) - 3L

if (maxi == Pmax + Qmax + Rmax) {
  Z <- Z[Z$Ncomp != max(Z$Ncomp), , drop = FALSE]
} else {
  Z <- Z[Z$Ncomp < maxi, , drop = FALSE]
}

rownames(Z) <- NULL
nZ <- nrow(Z)

if (nZ == 0L) {
  stop("No quedaron modelos candidatos identificables.")
}

##############################
# 7. ESTIMACION TUCKER3 COMUN
##############################

SCE <- rep(NA_real_, nZ)
convergio <- logical(nZ)
iteraciones <- integer(nZ)
cambio_rel_final <- rep(NA_real_, nZ)
A_list <- vector("list", nZ)
B_list <- vector("list", nZ)
C_list <- vector("list", nZ)
G1_list <- vector("list", nZ)
G2_list <- vector("list", nZ)
G3_list <- vector("list", nZ)

U1_inicial <- svd(X1, nu = Pmax, nv = 0L)$u
U2_inicial <- svd(X2, nu = Qmax, nv = 0L)$u
U3_inicial <- svd(X3, nu = Rmax, nv = 0L)$u

tiempo_total <- system.time({
  for (i in seq_len(nZ)) {
    p_i <- Z$P[i]
    q_i <- Z$Q[i]
    r_i <- Z$R[i]

    A_actual <- U1_inicial[, seq_len(p_i), drop = FALSE]
    B_actual <- U2_inicial[, seq_len(q_i), drop = FALSE]
    C_actual <- U3_inicial[, seq_len(r_i), drop = FALSE]
    sce_prev <- Inf

    for (iter in seq_len(max_iter)) {
      A_actual <- svd(
        X1 %*% kronecker(C_actual, B_actual),
        nu = p_i,
        nv = 0L
      )$u[, seq_len(p_i), drop = FALSE]

      B_actual <- svd(
        X2 %*% kronecker(C_actual, A_actual),
        nu = q_i,
        nv = 0L
      )$u[, seq_len(q_i), drop = FALSE]

      C_actual <- svd(
        X3 %*% kronecker(B_actual, A_actual),
        nu = r_i,
        nv = 0L
      )$u[, seq_len(r_i), drop = FALSE]

      G1_curr <- t(A_actual) %*% X1 %*%
        kronecker(C_actual, B_actual)

      X1_est <- A_actual %*% G1_curr %*%
        kronecker(t(C_actual), t(B_actual))
      sce_curr <- sum((X1 - X1_est)^2)

      if (!is.finite(sce_curr)) {
        stop(
          "SCE no finita para el modelo (",
          p_i, ", ", q_i, ", ", r_i, ")."
        )
      }

      if (is.finite(sce_prev)) {
        cambio_abs <- abs(sce_prev - sce_curr)
        escala_sce <- max(
          abs(sce_prev),
          abs(sce_curr),
          .Machine$double.eps
        )
        cambio_rel <- cambio_abs / escala_sce
      } else {
        cambio_rel <- Inf
      }

      cambio_rel_final[i] <- cambio_rel
      iteraciones[i] <- iter

      if (iter >= min_iter && cambio_rel <= tol) {
        convergio[i] <- TRUE
        break
      }

      sce_prev <- sce_curr
    }

    G2_curr <- t(B_actual) %*% X2 %*%
      kronecker(C_actual, A_actual)
    G3_curr <- t(C_actual) %*% X3 %*%
      kronecker(B_actual, A_actual)

    A_list[[i]] <- A_actual
    B_list[[i]] <- B_actual
    C_list[[i]] <- C_actual
    G1_list[[i]] <- G1_curr
    G2_list[[i]] <- G2_curr
    G3_list[[i]] <- G3_curr
    SCE[i] <- sce_curr

    if (!convergio[i]) {
      warning(
        "El modelo (", p_i, ", ", q_i, ", ", r_i,
        ") alcanzo max_iter sin converger."
      )
    }
  }
})

tiempo_total <- unname(tiempo_total[["elapsed"]])

##############################
# 8. TABLA GENERAL Y CURVA DE AJUSTE
##############################

SPM <- data.frame(
  modelo_id = seq_len(nZ),
  P = Z$P,
  Q = Z$Q,
  R = Z$R,
  `No de comp.` = Z$Ncomp,
  SCE = SCE,
  Ajuste_pct = (1 - SCE / SSX) * 100,
  Convergio = convergio,
  Iteraciones = iteraciones,
  `Cambio relativo final` = cambio_rel_final,
  check.names = FALSE
)

SPM <- SPM[
  order(SPM[["No de comp."]], SPM$P, SPM$Q, SPM$R),
  ,
  drop = FALSE
]
rownames(SPM) <- NULL

indices_mejores <- unlist(
  lapply(
    split(seq_len(nrow(SPM)), SPM[["No de comp."]]),
    function(idx) idx[which.min(SPM$SCE[idx])]
  ),
  use.names = FALSE
)

tabla_mejor_por_S <- SPM[
  indices_mejores,
  c(
    "modelo_id", "P", "Q", "R", "No de comp.", "SCE",
    "Ajuste_pct", "Convergio", "Iteraciones",
    "Cambio relativo final"
  ),
  drop = FALSE
]
tabla_mejor_por_S <- tabla_mejor_por_S[
  order(tabla_mejor_por_S[["No de comp."]]),
  ,
  drop = FALSE
]
rownames(tabla_mejor_por_S) <- NULL

ncomp <- tabla_mejor_por_S[["No de comp."]]
SCEmin <- tabla_mejor_por_S$SCE
ajuste_scree <- tabla_mejor_por_S$Ajuste_pct

mejora_sce <- head(SCEmin, -1L) - tail(SCEmin, -1L)
mejora_relativa <- mejora_sce / head(SCEmin, -1L)
salto_componentes <- diff(ncomp)
mejora_rel_por_componente <- mejora_relativa / salto_componentes

curvatura_scree <- rep(NA_real_, length(ncomp))
if (length(ncomp) >= 3L) {
  curvatura_scree[2L:(length(ncomp) - 1L)] <-
    diff(diff(ajuste_scree))
}

puntaje_diffit <- rep(NA_real_, length(ncomp))
if (length(mejora_sce) >= 2L) {
  for (i in seq_len(length(mejora_sce) - 1L)) {
    posteriores <- mejora_sce[(i + 1L):length(mejora_sce)]
    denom <- max(posteriores, na.rm = TRUE)
    puntaje_diffit[i + 1L] <- if (
      is.finite(denom) && denom > 0
    ) {
      mejora_sce[i] / denom
    } else {
      NA_real_
    }
  }
}

tabla_curva <- data.frame(
  S = ncomp,
  P = tabla_mejor_por_S$P,
  Q = tabla_mejor_por_S$Q,
  R = tabla_mejor_por_S$R,
  SCE_min = SCEmin,
  Ajuste_pct = ajuste_scree,
  Mejora_SCE_hacia_S = c(NA_real_, mejora_sce),
  Mejora_relativa_hacia_S = c(NA_real_, mejora_relativa),
  Salto_componentes = c(NA_integer_, salto_componentes),
  Mejora_relativa_por_componente = c(
    NA_real_,
    mejora_rel_por_componente
  ),
  Curvatura_scree = curvatura_scree,
  Puntaje_diffit = puntaje_diffit
)

##############################
# 9. SELECCION POR LOS DOS CRITERIOS
##############################

if (all(is.na(curvatura_scree))) {
  pos_scree <- which.max(ajuste_scree)
} else {
  pos_scree <- which.max(abs(curvatura_scree))
}
S_scree <- ncomp[pos_scree]

if (all(is.na(puntaje_diffit))) {
  pos_diffit <- which.min(SCEmin)
} else {
  pos_diffit <- which.max(puntaje_diffit)
}
S_diffit <- ncomp[pos_diffit]

seleccionar_fila <- function(S_objetivo) {
  candidatos <- which(SPM[["No de comp."]] == S_objetivo)
  candidatos[which.min(SPM$SCE[candidatos])]
}

fila_scree <- seleccionar_fila(S_scree)
fila_diffit <- seleccionar_fila(S_diffit)

construir_modelo <- function(fila_spm, criterio) {
  modelo_id <- SPM$modelo_id[fila_spm]
  p <- SPM$P[fila_spm]
  q <- SPM$Q[fila_spm]
  r <- SPM$R[fila_spm]

  A <- A_list[[modelo_id]]
  B <- B_list[[modelo_id]]
  C <- C_list[[modelo_id]]
  Ga <- G1_list[[modelo_id]]
  Gb <- G2_list[[modelo_id]]
  Gc <- G3_list[[modelo_id]]

  stopifnot(
    ncol(A) == p,
    ncol(B) == q,
    ncol(C) == r,
    all(dim(Ga) == c(p, q * r)),
    all(dim(Gb) == c(q, p * r)),
    all(dim(Gc) == c(r, p * q))
  )

  ajuste_core <- sum(Ga^2) / SSX * 100
  ajuste_sce <- (1 - SPM$SCE[fila_spm] / SSX) * 100

  if (!isTRUE(all.equal(ajuste_core, ajuste_sce, tolerance = 1e-6))) {
    stop(
      "El ajuste del core y de la SCE no coincide para ", criterio, "."
    )
  }

  Fa <- kronecker(C, B) %*% t(Ga)
  Fb <- kronecker(C, A) %*% t(Gb)
  Fc <- kronecker(B, A) %*% t(Gc)

  Ta <- diag_safe(svd(Fa, nu = 0L, nv = 0L)$d)
  Tb <- diag_safe(svd(Fb, nu = 0L, nv = 0L)$d)
  Tc <- diag_safe(svd(Fc, nu = 0L, nv = 0L)$d)

  list(
    criterio = criterio,
    fila_spm = fila_spm,
    modelo_id = modelo_id,
    p = p,
    q = q,
    r = r,
    S = p + q + r,
    SCE = SPM$SCE[fila_spm],
    ajuste = ajuste_core,
    convergio = SPM$Convergio[fila_spm],
    iteraciones = SPM$Iteraciones[fila_spm],
    cambio_rel = SPM[["Cambio relativo final"]][fila_spm],
    A = A,
    B = B,
    C = C,
    Ga = Ga,
    Gb = Gb,
    Gc = Gc,
    Fa = Fa,
    Fb = Fb,
    Fc = Fc,
    Amod = A %*% Ta,
    Bmod = B %*% Tb,
    Cmod = C %*% Tc,
    Famod = Fa %*% ginv(Ta),
    Fbmod = Fb %*% ginv(Tb),
    Fcmod = Fc %*% ginv(Tc),
    contribA = rowSums(Ga^2) / SSX * 100,
    contribB = rowSums(Gb^2) / SSX * 100,
    contribC = rowSums(Gc^2) / SSX * 100,
    contribTriada = Ga^2 / SSX * 100
  )
}

modelo_scree <- construir_modelo(fila_scree, "Scree corregido")
modelo_diffit <- construir_modelo(fila_diffit, "Dif-fit")
modelos <- list(Scree = modelo_scree, Diffit = modelo_diffit)

##############################
# 10. TABLAS COMPARATIVAS
##############################

tabla_comparacion_modelos <- do.call(
  rbind,
  lapply(modelos, function(m) {
    data.frame(
      Criterio = m$criterio,
      Fila_SPM = m$fila_spm,
      Modelo_id = m$modelo_id,
      P = m$p,
      Q = m$q,
      R = m$r,
      S = m$S,
      SCE = m$SCE,
      Ajuste_pct = m$ajuste,
      Residual_pct = 100 - m$ajuste,
      Convergio = m$convergio,
      Iteraciones = m$iteraciones,
      Cambio_relativo_final = m$cambio_rel
    )
  })
)
rownames(tabla_comparacion_modelos) <- NULL

tabla_diferencias <- data.frame(
  Indicador = c(
    "Diferencia de componentes totales",
    "Reduccion de SCE de Dif-fit respecto a Scree",
    "Ganancia de ajuste de Dif-fit (puntos porcentuales)",
    "Incremento relativo de ajuste (%)",
    "Los criterios seleccionaron el mismo modelo?"
  ),
  Valor = c(
    modelo_diffit$S - modelo_scree$S,
    modelo_scree$SCE - modelo_diffit$SCE,
    modelo_diffit$ajuste - modelo_scree$ajuste,
    100 * (
      modelo_diffit$ajuste - modelo_scree$ajuste
    ) / modelo_scree$ajuste,
    identical(
      c(modelo_scree$p, modelo_scree$q, modelo_scree$r),
      c(modelo_diffit$p, modelo_diffit$q, modelo_diffit$r)
    )
  ),
  stringsAsFactors = FALSE
)

tabla_contribuciones <- do.call(
  rbind,
  lapply(modelos, function(m) {
    rbind(
      data.frame(
        Criterio = m$criterio,
        Modo = "A",
        Componente = seq_along(m$contribA),
        Contribucion_pct = m$contribA
      ),
      data.frame(
        Criterio = m$criterio,
        Modo = "B",
        Componente = seq_along(m$contribB),
        Contribucion_pct = m$contribB
      ),
      data.frame(
        Criterio = m$criterio,
        Modo = "C",
        Componente = seq_along(m$contribC),
        Contribucion_pct = m$contribC
      )
    )
  })
)
rownames(tabla_contribuciones) <- NULL

tabla_resumen_vertical <- data.frame(
  Indicador = c(
    "Modelo (P,Q,R)",
    "Componentes totales S",
    "SCE",
    "Ajuste (%)",
    "Residual (%)",
    "Iteraciones",
    "Cambio relativo final"
  ),
  Scree_corregido = c(
    paste0(
      "(", modelo_scree$p, ",", modelo_scree$q, ",",
      modelo_scree$r, ")"
    ),
    modelo_scree$S,
    signif(modelo_scree$SCE, 8),
    round(modelo_scree$ajuste, 4),
    round(100 - modelo_scree$ajuste, 4),
    modelo_scree$iteraciones,
    signif(modelo_scree$cambio_rel, 8)
  ),
  Diffit = c(
    paste0(
      "(", modelo_diffit$p, ",", modelo_diffit$q, ",",
      modelo_diffit$r, ")"
    ),
    modelo_diffit$S,
    signif(modelo_diffit$SCE, 8),
    round(modelo_diffit$ajuste, 4),
    round(100 - modelo_diffit$ajuste, 4),
    modelo_diffit$iteraciones,
    signif(modelo_diffit$cambio_rel, 8)
  ),
  stringsAsFactors = FALSE
)

##############################
# 10B. DATOS EDITABLES PARA GRAFICOS EN EXCEL
##############################

coordenada <- function(matriz, componente) {
  if (ncol(matriz) >= componente) {
    matriz[, componente]
  } else {
    rep(NA_real_, nrow(matriz))
  }
}

datos_modos_modelo <- function(m) {
  rbind(
    data.frame(
      Criterio = m$criterio,
      Modo = "A",
      Tipo = "Punto",
      Etiqueta = ind,
      Eje1 = coordenada(m$Amod, 1L),
      Eje2 = coordenada(m$Amod, 2L)
    ),
    data.frame(
      Criterio = m$criterio,
      Modo = "A",
      Tipo = "Flecha",
      Etiqueta = varcond,
      Eje1 = coordenada(m$Famod, 1L),
      Eje2 = coordenada(m$Famod, 2L)
    ),
    data.frame(
      Criterio = m$criterio,
      Modo = "B",
      Tipo = "Punto",
      Etiqueta = var,
      Eje1 = coordenada(m$Bmod, 1L),
      Eje2 = coordenada(m$Bmod, 2L)
    ),
    data.frame(
      Criterio = m$criterio,
      Modo = "B",
      Tipo = "Flecha",
      Etiqueta = indcond,
      Eje1 = coordenada(m$Fbmod, 1L),
      Eje2 = coordenada(m$Fbmod, 2L)
    ),
    data.frame(
      Criterio = m$criterio,
      Modo = "C",
      Tipo = "Punto",
      Etiqueta = cond,
      Eje1 = coordenada(m$Cmod, 1L),
      Eje2 = coordenada(m$Cmod, 2L)
    ),
    data.frame(
      Criterio = m$criterio,
      Modo = "C",
      Tipo = "Flecha",
      Etiqueta = indvar,
      Eje1 = coordenada(m$Fcmod, 1L),
      Eje2 = coordenada(m$Fcmod, 2L)
    )
  )
}

datos_trayectorias_modelo <- function(m) {
  datos_ac <- data.frame(
    Criterio = m$criterio,
    Combinacion = "AC",
    Tipo = "Trayectoria",
    Grupo = rep(ind, times = length(cond)),
    Condicion = rep(cond, each = length(ind)),
    Orden = rep(seq_along(cond), each = length(ind)),
    Etiqueta = indcond,
    Eje1 = coordenada(m$Fb, 1L),
    Eje2 = coordenada(m$Fb, 2L)
  )

  flechas_ac <- data.frame(
    Criterio = m$criterio,
    Combinacion = "AC",
    Tipo = "Flecha",
    Grupo = var,
    Condicion = NA_character_,
    Orden = NA_integer_,
    Etiqueta = var,
    Eje1 = coordenada(m$B, 1L),
    Eje2 = coordenada(m$B, 2L)
  )

  datos_bc <- data.frame(
    Criterio = m$criterio,
    Combinacion = "BC",
    Tipo = "Trayectoria",
    Grupo = rep(var, times = length(cond)),
    Condicion = rep(cond, each = length(var)),
    Orden = rep(seq_along(cond), each = length(var)),
    Etiqueta = varcond,
    Eje1 = coordenada(m$Fa, 1L),
    Eje2 = coordenada(m$Fa, 2L)
  )

  flechas_bc <- data.frame(
    Criterio = m$criterio,
    Combinacion = "BC",
    Tipo = "Flecha",
    Grupo = ind,
    Condicion = NA_character_,
    Orden = NA_integer_,
    Etiqueta = ind,
    Eje1 = coordenada(m$A, 1L),
    Eje2 = coordenada(m$A, 2L)
  )

  datos_ab <- data.frame(
    Criterio = m$criterio,
    Combinacion = "AB",
    Tipo = "Trayectoria",
    Grupo = rep(ind, times = length(var)),
    Condicion = rep(var, each = length(ind)),
    Orden = rep(seq_along(var), each = length(ind)),
    Etiqueta = indvar,
    Eje1 = coordenada(m$Fc, 1L),
    Eje2 = coordenada(m$Fc, 2L)
  )

  flechas_ab <- data.frame(
    Criterio = m$criterio,
    Combinacion = "AB",
    Tipo = "Flecha",
    Grupo = cond,
    Condicion = NA_character_,
    Orden = NA_integer_,
    Etiqueta = cond,
    Eje1 = coordenada(m$C, 1L),
    Eje2 = coordenada(m$C, 2L)
  )

  rbind(
    datos_ac,
    flechas_ac,
    datos_bc,
    flechas_bc,
    datos_ab,
    flechas_ab
  )
}

datos_core_modelo <- function(m) {
  indices <- do.call(
    rbind,
    lapply(seq_len(m$p), function(a) {
      combinaciones <- expand.grid(
        B = seq_len(m$q),
        C = seq_len(m$r)
      )
      data.frame(
        A = a,
        B = combinaciones$B,
        C = combinaciones$C
      )
    })
  )

  data.frame(
    Criterio = m$criterio,
    A = indices$A,
    B = indices$B,
    C = indices$C,
    Combinacion_BC = paste0("B", indices$B, "-C", indices$C),
    Valor_core = as.vector(t(m$Ga)),
    Contribucion_pct = as.vector(t(m$contribTriada))
  )
}

datos_modos_excel <- do.call(
  rbind,
  lapply(modelos, datos_modos_modelo)
)
rownames(datos_modos_excel) <- NULL

datos_trayectorias_excel <- do.call(
  rbind,
  lapply(modelos, datos_trayectorias_modelo)
)
rownames(datos_trayectorias_excel) <- NULL

datos_core_excel <- do.call(
  rbind,
  lapply(modelos, datos_core_modelo)
)
rownames(datos_core_excel) <- NULL

datos_scree_excel <- data.frame(
  S = ncomp,
  SCE_min = SCEmin,
  Ajuste_pct = ajuste_scree,
  Ajuste_seleccion_scree = ifelse(
    ncomp == modelo_scree$S,
    ajuste_scree,
    NA_real_
  ),
  Ajuste_seleccion_diffit = ifelse(
    ncomp == modelo_diffit$S,
    ajuste_scree,
    NA_real_
  ),
  SCE_seleccion_scree = ifelse(
    ncomp == modelo_scree$S,
    SCEmin,
    NA_real_
  ),
  SCE_seleccion_diffit = ifelse(
    ncomp == modelo_diffit$S,
    SCEmin,
    NA_real_
  )
)

guia_graficos_excel <- data.frame(
  Hoja = c(
    "Datos_scree",
    "Datos_modos",
    "Datos_trayectorias",
    "Datos_core",
    "Contribuciones"
  ),
  Grafico_recomendado = c(
    "Linea con marcadores",
    "Dispersion XY",
    "Dispersion XY con lineas",
    "Mapa de calor o columnas",
    "Columnas agrupadas"
  ),
  Filtros_recomendados = c(
    "Ninguno; usar S como eje horizontal",
    "Criterio, Modo y Tipo",
    "Criterio, Combinacion, Tipo y Grupo",
    "Criterio y componente A",
    "Criterio y Modo"
  ),
  Uso = c(
    "Comparar ajuste y SCE, destacando las dos selecciones.",
    "Recrear puntos y flechas de las representaciones modales.",
    "Recrear cada trayectoria respetando Grupo y Orden.",
    "Representar valores o contribuciones de cada triada A-B-C.",
    "Comparar la contribucion porcentual de los componentes."
  ),
  stringsAsFactors = FALSE
)

##############################
# 11. GRAFICOS COMPARATIVOS
##############################

graficar_scree_comparativo <- function() {
  plot(
    ncomp,
    ajuste_scree,
    type = "b",
    pch = 19,
    xlab = "Numero total de componentes S",
    ylab = "Ajuste (%)",
    main = "Scree multiway: comparacion de criterios"
  )
  points(
    modelo_scree$S,
    modelo_scree$ajuste,
    pch = 21,
    bg = "dodgerblue",
    cex = 1.8
  )
  points(
    modelo_diffit$S,
    modelo_diffit$ajuste,
    pch = 22,
    bg = "tomato",
    cex = 1.8
  )
  legend(
    "bottomright",
    legend = c("Scree corregido", "Dif-fit"),
    pch = c(21, 22),
    pt.bg = c("dodgerblue", "tomato"),
    bty = "n"
  )

  plot(
    ncomp,
    SCEmin,
    type = "b",
    log = "y",
    pch = 19,
    xlab = "Numero total de componentes S",
    ylab = "SCE (escala logaritmica)",
    main = "SCE minima por numero de componentes"
  )
  points(
    modelo_scree$S,
    modelo_scree$SCE,
    pch = 21,
    bg = "dodgerblue",
    cex = 1.8
  )
  points(
    modelo_diffit$S,
    modelo_diffit$SCE,
    pch = 22,
    bg = "tomato",
    cex = 1.8
  )
  legend(
    "topright",
    legend = c("Scree corregido", "Dif-fit"),
    pch = c(21, 22),
    pt.bg = c("dodgerblue", "tomato"),
    bty = "n"
  )
}

graficar_modos <- function(m) {
  prefijo <- paste0(
    m$criterio, " - Tucker3 (", m$p, ",", m$q, ",", m$r, ")"
  )

  if (m$p >= 2L) {
    puntos <- m$Amod[, 1:2, drop = FALSE]
    flechas <- m$Famod[, 1:2, drop = FALSE]
    limites <- rangos_comunes(puntos, flechas)
    s.label(
      puntos,
      label = ind,
      clabel = 0.6,
      xlim = limites$xlim,
      ylim = limites$ylim,
      sub = paste(prefijo, "- modo A"),
      csub = 1
    )
    s.arrow(
      flechas,
      label = varcond,
      clabel = 0.4,
      boxes = FALSE,
      add.plot = TRUE
    )
  } else {
    grafico_no_disponible(
      paste(prefijo, "- modo A"),
      "El modo A tiene una sola componente."
    )
  }

  if (m$q >= 2L) {
    puntos <- m$Bmod[, 1:2, drop = FALSE]
    flechas <- m$Fbmod[, 1:2, drop = FALSE]
    limites <- rangos_comunes(puntos, flechas)
    s.label(
      puntos,
      label = var,
      clabel = 0.7,
      xlim = limites$xlim,
      ylim = limites$ylim,
      sub = paste(prefijo, "- modo B"),
      csub = 1
    )
    s.arrow(
      flechas,
      label = indcond,
      clabel = 0.4,
      boxes = FALSE,
      add.plot = TRUE
    )
  } else {
    grafico_no_disponible(
      paste(prefijo, "- modo B"),
      "El modo B tiene una sola componente."
    )
  }

  if (m$r >= 2L) {
    puntos <- m$Cmod[, 1:2, drop = FALSE]
    flechas <- m$Fcmod[, 1:2, drop = FALSE]
    limites <- rangos_comunes(puntos, flechas)
    s.label(
      puntos,
      label = cond,
      clabel = 0.7,
      xlim = limites$xlim,
      ylim = limites$ylim,
      sub = paste(prefijo, "- modo C"),
      csub = 1
    )
    s.arrow(
      flechas,
      label = indvar,
      clabel = 0.4,
      boxes = FALSE,
      add.plot = TRUE
    )
  } else {
    grafico_no_disponible(
      paste(prefijo, "- modo C"),
      "El modo C tiene una sola componente; no existe plano C1-C2."
    )
  }
}

graficar_trayectorias <- function(m) {
  prefijo <- paste0(
    m$criterio, " - Tucker3 (", m$p, ",", m$q, ",", m$r, ")"
  )

  if (m$q >= 2L) {
    Fbd <- m$Fb[, 1:2, drop = FALSE]
    Bd <- m$B[, 1:2, drop = FALSE]
    limites <- rangos_comunes(Fbd, Bd)
    fac <- factor(rep(seq_len(nrow(m$A)), times = nrow(m$C)))
    s.traject(
      Fbd,
      fac = fac,
      ord = seq_along(fac),
      label = NULL,
      clabel = 0.6,
      cpoint = 0.8,
      grid = TRUE,
      addaxes = TRUE,
      edge = FALSE,
      origin = c(0, 0),
      include.origin = TRUE,
      sub = paste(prefijo, "- trayectorias AC"),
      csub = 1,
      xlim = limites$xlim,
      ylim = limites$ylim
    )
    s.arrow(
      Bd,
      label = var,
      clabel = 0.6,
      boxes = FALSE,
      add.plot = TRUE
    )
    text(Fbd[, 1L], Fbd[, 2L], indcond, pos = 1, cex = 0.4)
  } else {
    grafico_no_disponible(
      paste(prefijo, "- trayectorias AC"),
      "Se necesitan al menos dos componentes B."
    )
  }

  if (m$p >= 2L) {
    Fad <- m$Fa[, 1:2, drop = FALSE]
    Ad <- m$A[, 1:2, drop = FALSE]
    limites <- rangos_comunes(Fad, Ad)
    fac <- factor(rep(seq_len(nrow(m$B)), times = nrow(m$C)))
    s.traject(
      Fad,
      fac = fac,
      ord = seq_along(fac),
      label = NULL,
      clabel = 0.5,
      cpoint = 0.8,
      grid = TRUE,
      addaxes = TRUE,
      edge = FALSE,
      origin = c(0, 0),
      include.origin = TRUE,
      sub = paste(prefijo, "- trayectorias BC"),
      csub = 1,
      xlim = limites$xlim,
      ylim = limites$ylim
    )
    s.arrow(
      Ad,
      label = ind,
      clabel = 0.5,
      boxes = FALSE,
      add.plot = TRUE
    )
    text(Fad[, 1L], Fad[, 2L], varcond, pos = 1, cex = 0.4)
  } else {
    grafico_no_disponible(
      paste(prefijo, "- trayectorias BC"),
      "Se necesitan al menos dos componentes A."
    )
  }

  if (m$r >= 2L) {
    Fcd <- m$Fc[, 1:2, drop = FALSE]
    Cd <- m$C[, 1:2, drop = FALSE]
    limites <- rangos_comunes(Fcd, Cd)
    fac <- factor(rep(seq_len(nrow(m$A)), times = nrow(m$B)))
    s.traject(
      Fcd,
      fac = fac,
      ord = seq_along(fac),
      label = NULL,
      clabel = 0.5,
      cpoint = 0.8,
      grid = TRUE,
      addaxes = TRUE,
      edge = FALSE,
      origin = c(0, 0),
      include.origin = TRUE,
      sub = paste(prefijo, "- trayectorias AB"),
      csub = 1,
      xlim = limites$xlim,
      ylim = limites$ylim
    )
    s.arrow(
      Cd,
      label = cond,
      clabel = 0.6,
      boxes = FALSE,
      add.plot = TRUE
    )
    text(Fcd[, 1L], Fcd[, 2L], indvar, pos = 1, cex = 0.4)
  } else {
    grafico_no_disponible(
      paste(prefijo, "- trayectorias AB"),
      "El modo C tiene una sola componente; no existe plano C1-C2."
    )
  }
}

graficar_core <- function(m) {
  etiquetas_bc <- as.vector(
    outer(
      paste0("B", seq_len(m$q)),
      paste0("C", seq_len(m$r)),
      paste,
      sep = "-"
    )
  )

  image(
    seq_len(ncol(m$Ga)),
    seq_len(nrow(m$Ga)),
    t(m$Ga[rev(seq_len(nrow(m$Ga))), , drop = FALSE]),
    xlab = "Combinaciones B-C",
    ylab = "Componentes A",
    main = paste(
      m$criterio, "- mapa de calor del core",
      paste0("(", m$p, ",", m$q, ",", m$r, ")")
    ),
    axes = FALSE,
    col = hcl.colors(30L, "Blue-Red 3")
  )
  axis(
    1,
    at = seq_along(etiquetas_bc),
    labels = etiquetas_bc,
    las = 2,
    cex.axis = 0.7
  )
  axis(
    2,
    at = seq_len(m$p),
    labels = paste0("A", rev(seq_len(m$p)))
  )
  box()

  indices <- seq(from = 1L, by = m$q, length.out = m$r)
  valores <- m$Ga[1L, indices]
  plot(
    seq_len(m$r),
    valores,
    type = "b",
    pch = 19,
    xaxt = "n",
    xlim = c(1, max(2, m$r)),
    xlab = "Componentes C",
    ylab = "Valor del core",
    main = paste(m$criterio, "- perfil del core A1-B1")
  )
  axis(1, at = seq_len(m$r), labels = paste0("C", seq_len(m$r)))
  text(
    seq_len(m$r),
    valores,
    labels = signif(valores, 4),
    pos = 3,
    cex = 0.8
  )

  contribuciones <- c(m$contribA, m$contribB, m$contribC)
  etiquetas <- c(
    paste0("A", seq_along(m$contribA)),
    paste0("B", seq_along(m$contribB)),
    paste0("C", seq_along(m$contribC))
  )
  colores <- c(
    rep("steelblue", length(m$contribA)),
    rep("darkorange", length(m$contribB)),
    rep("seagreen", length(m$contribC))
  )
  barplot(
    contribuciones,
    names.arg = etiquetas,
    col = colores,
    las = 2,
    ylab = "Contribucion (%)",
    main = paste(m$criterio, "- contribucion por componente")
  )
}

generar_todos_los_graficos <- function() {
  graficar_scree_comparativo()

  for (m in modelos) {
    graficar_modos(m)
    graficar_trayectorias(m)
    graficar_core(m)
  }
}

if (interactive()) {
  generar_todos_los_graficos()
} else {
  message(
    "La sesión no es interactiva. Para visualizar las figuras, ",
    "ejecuta generar_todos_los_graficos() desde RStudio."
  )
}

##############################
# 12. EXPORTACION A EXCEL
##############################

salida_excel <- list(
  Comparacion = tabla_comparacion_modelos,
  Resumen_vertical = tabla_resumen_vertical,
  Diferencias = tabla_diferencias,
  Guia_graficos = guia_graficos_excel,
  Datos_scree = datos_scree_excel,
  Datos_modos = datos_modos_excel,
  Datos_trayectorias = datos_trayectorias_excel,
  Datos_core = datos_core_excel,
  Mejor_modelo_por_S = tabla_mejor_por_S,
  Curva_criterios = tabla_curva,
  SPM_completa = SPM,
  Contribuciones = tabla_contribuciones,
  Scree_A = as.data.frame(modelo_scree$A),
  Scree_B = as.data.frame(modelo_scree$B),
  Scree_C = as.data.frame(modelo_scree$C),
  Scree_core_Ga = as.data.frame(modelo_scree$Ga),
  Scree_contrib_triada = as.data.frame(modelo_scree$contribTriada),
  Diffit_A = as.data.frame(modelo_diffit$A),
  Diffit_B = as.data.frame(modelo_diffit$B),
  Diffit_C = as.data.frame(modelo_diffit$C),
  Diffit_core_Ga = as.data.frame(modelo_diffit$Ga),
  Diffit_contrib_triada = as.data.frame(modelo_diffit$contribTriada)
)

wb_salida <- createWorkbook()

estilo_entero <- createStyle(numFmt = "0")
estilo_decimal <- createStyle(numFmt = "0.0000")
estilo_cientifico <- createStyle(numFmt = "0.000000E+00")

for (i in seq_along(salida_excel)) {
  nombre_hoja <- names(salida_excel)[i]
  datos_hoja <- salida_excel[[i]]

  addWorksheet(wb_salida, nombre_hoja, gridLines = FALSE)

  if (nrow(datos_hoja) > 0L && ncol(datos_hoja) > 0L) {
    writeDataTable(
      wb_salida,
      nombre_hoja,
      datos_hoja,
      tableName = paste0("Tabla", sprintf("%02d", i)),
      tableStyle = "TableStyleMedium2",
      withFilter = nrow(datos_hoja) > 1L
    )

    freezePane(wb_salida, nombre_hoja, firstRow = TRUE)
    setColWidths(
      wb_salida,
      nombre_hoja,
      cols = seq_len(ncol(datos_hoja)),
      widths = "auto"
    )

    for (j in seq_along(datos_hoja)) {
      if (!is.numeric(datos_hoja[[j]])) {
        next
      }

      nombre_columna <- names(datos_hoja)[j]
      filas_datos <- 2L:(nrow(datos_hoja) + 1L)

      if (grepl("SCE|Cambio|core|Ga", nombre_columna, ignore.case = TRUE)) {
        addStyle(
          wb_salida,
          nombre_hoja,
          estilo_cientifico,
          rows = filas_datos,
          cols = j,
          gridExpand = TRUE
        )
      } else if (
        grepl(
          "pct|Ajuste|Residual|Contribucion|Proporcion|Mejora",
          nombre_columna,
          ignore.case = TRUE
        )
      ) {
        addStyle(
          wb_salida,
          nombre_hoja,
          estilo_decimal,
          rows = filas_datos,
          cols = j,
          gridExpand = TRUE
        )
      } else if (
        all(
          datos_hoja[[j]] == trunc(datos_hoja[[j]]),
          na.rm = TRUE
        )
      ) {
        addStyle(
          wb_salida,
          nombre_hoja,
          estilo_entero,
          rows = filas_datos,
          cols = j,
          gridExpand = TRUE
        )
      }
    }
  }
}

saveWorkbook(wb_salida, archivo_excel, overwrite = TRUE)

##############################
# 13. IMPRESION FINAL
##############################

options(width = 160)

cat("\n========================================\n")
cat("TIEMPO DE ESTIMACION TUCKER3\n")
cat("========================================\n")
cat(
  "Tiempo total:",
  round(tiempo_total, 4),
  "segundos (",
  round(tiempo_total / 60, 4),
  "minutos )\n",
  sep = " "
)

cat("\n========================================\n")
cat("TABLA GENERAL DE MODELOS - SPM\n")
cat("========================================\n")
print(SPM, row.names = FALSE)

cat("\n========================================\n")
cat("CURVA DE AJUSTE Y CRITERIOS\n")
cat("========================================\n")
print(tabla_curva, row.names = FALSE)

cat("\n========================================\n")
cat("MEJOR MODELO PARA CADA NUMERO DE COMPONENTES S\n")
cat("========================================\n")
print(tabla_mejor_por_S, row.names = FALSE)

cat("\n========================================\n")
cat("SELECCION POR LOS DOS CRITERIOS\n")
cat("========================================\n")
print(tabla_comparacion_modelos, row.names = FALSE)

cat("\n========================================\n")
cat("RESUMEN COMPARATIVO VERTICAL\n")
cat("========================================\n")
print(tabla_resumen_vertical, row.names = FALSE)

cat("\n========================================\n")
cat("\nDIFERENCIAS ENTRE CRITERIOS\n")
cat("========================================\n")
print(tabla_diferencias, row.names = FALSE)

cat("\n========================================\n")
cat("CONTRIBUCIONES DE COMPONENTES\n")
cat("========================================\n")
print(tabla_contribuciones, row.names = FALSE)

cat("\n========================================\n")
cat("RESUMEN DE EJECUCION\n")
cat("========================================\n")
cat("Tiempo de estimacion:", round(tiempo_total, 4), "segundos\n")
cat("Modelos candidatos:", nZ, "\n")
cat("Modelos sin converger:", sum(!convergio), "\n")
cat("Excel:", archivo_excel, "\n")
cat(
  "Figuras disponibles en el panel Plots de RStudio.",
  " Usa las flechas para recorrerlas.\n"
)

##############################
# FIN
##############################
